class Triangle {
    constructor ( a, b, c ) {
        this.result = "The inputs belong to invalid range"
        this.setSides( a, b, c )
    }

 
    setSides( a, b, c) {
        let validInput = -1
        if ( (a > 0) && ( a < 100) && (b > 0) && ( b <= 100) && ( c > 0) && (c <= 100) ) {
            if ( ( (a+b) > c) && ( (c+a) > b) && ( (b+c) >a )) { 
                validInput = 1;
            } 
        } 
       if ( validInput === 1 ) { 
            if ( ( a === b ) && ( b === c )) {
                 this.result = "EQUILATERAL"
            }
            else if ( ( a === b ) || ( b === c ) || ( c === a ) ) {
                this.result = "ISOSCELES"
            } 
            else {
                this.result = "SCALENE"
            } 
        }
	/*	
		function whichTriangle(a,b,c) {
    // let side1 = document.getElementById('sideA').value();
    // let side2 = document.getElementById('sideB').value();
    // let side3 = document.getElementById('sideC').value();
    if (a === b && a === c) {
        console.log("triangle is Equilateral");
        return 'Equilateral';
    }
    else if (a === b && a != c) {
        console.log("triangle is an isosceles");
        return 'Isosceles';
    }
    else if (a != b && a != c && b != c) {
        console.log('triangle is a scalene');
        return 'Scalene';
    }
    else if ( a === null || a === undefined ||
        b === null || b === undefined ||
        c === null || c === undefined) {
        console.log('You must enter a number for all 3 sides');
    }
    else {
        console.log('You got me I don\'t know what this shape is. Maybe a rectangle?');
    }
    throw new Error('Not a triangle');
}*/


if (a < 0) 
		throw "Only positive length sides are allowed";
	if (a * b * c == 0)
		throw "Triangle cannot have zero area";
	if (a + b < c)
		throw "Not a valid triangle";

        else if ( validInput === 0 ) { 
            this.result = "The values do not constitute a triangle"
        }
    }*/
	
}
        